Steps: baseline -> run compliance -> review drift -> remediate
