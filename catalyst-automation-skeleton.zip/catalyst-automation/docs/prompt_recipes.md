Prompts you can paste for ChatGPT when generating code.
