| Model | Notes |
| --- | --- |
| C9300X | access/distribution |
| IE-3300 | ruggedized |
