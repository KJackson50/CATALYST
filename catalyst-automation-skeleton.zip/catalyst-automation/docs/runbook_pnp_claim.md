Steps: pre-check -> claim -> provision -> verify
