Batch show commands -> parse -> export
